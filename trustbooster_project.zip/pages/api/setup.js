let users = {}; // temporary in-memory store

export default function handler(req, res) {
  const { user, businessName, reviewLink } = req.body;

  if (!user || !businessName || !reviewLink) {
    return res.status(400).json({ success: false, message: 'Missing fields' });
  }

  if (!users[user]) users[user] = { contacts: [] };
  users[user] = {
    ...users[user],
    businessName,
    reviewLink,
    setupAt: new Date().toISOString(),
  };

  res.status(200).json({ success: true });
}
