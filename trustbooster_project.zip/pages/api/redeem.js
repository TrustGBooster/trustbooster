// File: pages/api/redeem.js
// ... (unchanged)
