import twilio from 'twilio';

const client = twilio(process.env.TWILIO_SID, process.env.TWILIO_AUTH);

export default function handler(req, res) {
  const { user, name, phone } = req.body;
  if (!user || !name || !phone) {
    return res.status(400).json({ success: false });
  }

  const reviewLink = users[user]?.reviewLink || 'https://google.com';
  if (users[user]) {
    users[user].contacts.push({ name, phone, time: new Date().toISOString() });
  }

  client.messages
    .create({
      to: phone,
      from: process.env.TWILIO_PHONE,
      body: `Hi ${name}, thanks for visiting! Would you mind leaving a review? ${reviewLink}`,
    })
    .then(() => res.status(200).json({ success: true }))
    .catch(() => res.status(500).json({ success: false }));
}
