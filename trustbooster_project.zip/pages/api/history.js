export default function handler(req, res) {
  const { user } = req.query;
  if (!user || !users[user]) {
    return res.status(200).json({ requests: [] });
  }
  res.status(200).json({ requests: users[user].contacts || [] });
}
