// File: pages/redeem.jsx
// ... (unchanged)
